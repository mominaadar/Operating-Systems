#include <stdio.h>
#include <stdlib.h> //system
#include <sys/types.h> //fork and wait
#include <unistd.h> //fork
#include <sys/wait.h> //wait

void main(){

	printf("exec file\n");

}
